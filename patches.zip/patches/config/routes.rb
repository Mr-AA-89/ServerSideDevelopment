Rails.application.routes.draw do

#  devise_for :users
#  get 'cart/index'

#  resources :items
 root 'static_pages#home'

#  get '/help' => 'static_pages#help'

#  get '/about' => 'static_pages#about'

#get '/cart' => 'cart#index'

#get '/cart/clear' => 'cart#clear'
#get '/cart/:id' => 'cart#add'
#get '/cart/remove/:id' => 'cart#remove'  
  
  get 'static_pages/home'
  get 'static_pages/profile'
  get 'static_pages/games'
  get 'static_pages/logIn'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
