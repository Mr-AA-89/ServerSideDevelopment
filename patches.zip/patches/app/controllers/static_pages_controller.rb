class StaticPagesController < ApplicationController
  def home
  end

  def profile
  end

  def games
  end

  def logIn
  end
end
